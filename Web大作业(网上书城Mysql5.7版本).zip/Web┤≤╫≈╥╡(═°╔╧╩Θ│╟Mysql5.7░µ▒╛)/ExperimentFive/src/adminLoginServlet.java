import bean.UserDaoImpl;
import bean.adminDao;
import bean.adminDaoImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "adminLoginServlet",urlPatterns = "/adminLoginServlet")
public class adminLoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //设置编码和响应类型
        response.setContentType("text/html");
        response.setCharacterEncoding("utf-8");
        request.setCharacterEncoding("utf-8");
        HttpSession session =request.getSession(true);
        //         1.获得用户名和密码
        //       2.验证用户名和密码是否正确 "zhou" "123456"
        String adminname=request.getParameter("adminName");
        String password=request.getParameter("adminPasswd");
        //获得响应的输出流
        PrintWriter pw=response.getWriter();
        adminDao dao = new adminDaoImpl();
        String name=dao.queryadmin(adminname).getName();
        String passwd=dao.queryadmin(adminname).getPassword();
        if(adminname.equals(name)&&password.equals(passwd)){
            session.setAttribute("admin",name);
            request.getRequestDispatcher("/adminnavcation.jsp").forward(request,response);
        }else {
            //验证失败
            pw.println("<font color='green'><h2>登录失败</h2></font>");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request,response);
    }
}
