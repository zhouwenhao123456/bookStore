import bean.User;
import bean.UserDaoImpl;

import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@javax.servlet.annotation.WebServlet(name = "loginServlet",urlPatterns="/loginServlet")
public class loginServlet extends javax.servlet.http.HttpServlet {

    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {

        //设置编码和响应类型
        response.setContentType("text/html");
        response.setCharacterEncoding("utf-8");
        request.setCharacterEncoding("utf-8");
        HttpSession session =request.getSession(true);
        //         1.获得用户名和密码
        //       2.验证用户名和密码是否正确 "zhou" "123456"
        String username=request.getParameter("userName");
        String password=request.getParameter("userPasswd");
        //获得响应的输出流
        PrintWriter pw=response.getWriter();
        UserDaoImpl dao =new UserDaoImpl();
        String name=dao.queryuser(username).getName();
        String passwd=dao.queryuser(username).getPassword();
        if(username.equals(name)&&password.equals(passwd)){
            session.setAttribute("user",username);
            request.getRequestDispatcher("/books.jsp").forward(request,response);
        }else {
            //验证失败
            pw.println("<font color='green'><h2>登录失败</h2></font>");
        }
    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
       this.doPost(request,response);
    }
}
