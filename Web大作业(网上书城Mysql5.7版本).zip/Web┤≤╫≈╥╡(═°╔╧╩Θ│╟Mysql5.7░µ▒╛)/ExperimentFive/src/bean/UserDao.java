package bean;
public interface UserDao {
    public void adduser(User u);
    public User queryuser(String username);
    public void updatepassword(String name,String password);
    public void updateaddr(String name,String addr);
}
