package bean;

public interface adminDao {
    public void addadmin(admin a);
    public admin queryadmin(String username);
}
