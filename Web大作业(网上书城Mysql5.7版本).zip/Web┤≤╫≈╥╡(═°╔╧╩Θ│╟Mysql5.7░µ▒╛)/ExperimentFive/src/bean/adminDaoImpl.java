package bean;

import utils.JDBCUtil;

import java.sql.*;

public  class adminDaoImpl implements adminDao{

    public void addadmin(admin a) {
        //连接数据库
        Connection conn = null;
        PreparedStatement psql=null;
        ResultSet rs=null;
        try {
            conn = JDBCUtil.getConnection();
            String sql = "insert into admin value (?,?)";
            conn = JDBCUtil.getConnection();
            psql=conn.prepareStatement(sql);
            psql.setString(1,a.getName());
            psql.setString(2,a.getPassword());
            int i = psql.executeUpdate();
            if(i>0){
                System.out.println("插入成功！");
            }else {
                System.out.println("插入失败！");
            }
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JDBCUtil.close(psql, conn);
        }
    }

    public admin queryadmin(String username) {

        //连接数据库
        Connection conn = null;
        Statement statement=null;
        ResultSet rs=null;
        admin a=new admin();

        try {
            conn = JDBCUtil.getConnection();
            statement = conn.createStatement();
            String sql = "select * from admin where name ='" + username + "'";
            rs=statement.executeQuery(sql);
            while(rs.next()){

                a.setName(rs.getString("name"));
                a.setPassword(rs.getString("password"));
            }
            rs.close();
            conn.close();
            return a;
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JDBCUtil.close(statement, conn);
        }
        return a;
    }
}
