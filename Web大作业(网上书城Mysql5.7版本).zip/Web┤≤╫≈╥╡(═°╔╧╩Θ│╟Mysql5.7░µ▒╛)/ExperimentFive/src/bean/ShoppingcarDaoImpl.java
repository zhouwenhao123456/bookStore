package bean;


import utils.JDBCUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ShoppingcarDaoImpl implements ShoppingcarDao{

    public void DeleteBook(String id){
        //连接数据库
        Connection conn = null;
        Statement statement=null;
        ResultSet rs=null;
        try {
            conn = JDBCUtil.getConnection();
            statement = conn.createStatement();
            String sql = "delete  from shoppingcar where bookid="+id;
            statement.executeUpdate(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JDBCUtil.close(statement, conn);
        }
    }
    public Book querybook(String id){
        //连接数据库
        Connection conn = null;
        Statement statement=null;
        ResultSet rs=null;
        Book b=new Book();
        try {
            conn = JDBCUtil.getConnection();
            statement = conn.createStatement();
            String sql = "select * from atm.book where bID="+id;
            rs=statement.executeQuery(sql);
            while(rs.next()){

                ShoppingCar s=new ShoppingCar();
                b.setName(rs.getString(1));
                b.setAuthor(rs.getString(2));
                b.setType(rs.getString(3));
                b.setId(rs.getString(4));
                b.setNumber(rs.getInt(5));
                b.setPrice(rs.getInt(6));
            }
            rs.close();
            conn.close();
            return b;
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JDBCUtil.close(statement, conn);
        }
        return b;
    }
    public void inserts(Book b,String username,int number){
        //连接数据库
        Connection conn = null;
        PreparedStatement psql=null;
        ResultSet rs=null;
        try {
            conn = JDBCUtil.getConnection();
            psql= conn.prepareStatement("insert shoppingcar(username, bookid, bookname, bookprice, booknumber)"+"values(?,?,?,?,?)");
            psql.setString(1,username);
            psql.setString(2, b.getId());
            psql.setString(3, b.getName());
            psql.setInt(4,b.getPrice());
            psql.setInt(5,number);
            psql.execute();
            conn.close();
        }
        catch (SQLException e){
            e.printStackTrace();
        }finally {
            JDBCUtil.close(psql, conn);
        }
    }
    public void update(Book b,String username,int number){
        //连接数据库
        Connection conn = null;
        PreparedStatement psql=null;
        ResultSet rs=null;
        List<ShoppingCar> list=new ArrayList<ShoppingCar>();
        try {
            conn = JDBCUtil.getConnection();
            psql= conn.prepareStatement("update shoppingcar set booknumber = ? where bookid=? and username in (select username from user where username='" + username + "')");
            //psql= conn.prepareStatement("update shoppingcar set booknumber = ? where bookid=?");
            //psql= conn.prepareStatement("update shoppingcar set booknumber = ? where (bookid=? and username='\" + username + \"')");
            //psql= conn.prepareStatement("update shoppingcar set booknumber = ? where bookid=? and username='\" + username + \"'");
            //psql= conn.prepareStatement("update shoppingcar set username,bookid,bookname,bookprice,booknumber=? where username=?");
            psql.setInt(1,number);
            psql.setString(2,b.getId());
            psql.execute();
            conn.close();
            } catch (SQLException e){
            e.printStackTrace();
        }finally {
            JDBCUtil.close(psql, conn);
        }
    }

    public ShoppingCar Queryone1(String username, String id) {
        //连接数据库
        Connection conn = null;
        Statement statement=null;
        ResultSet rs=null;
        ShoppingCar s=new ShoppingCar();
        try {
            conn = JDBCUtil.getConnection();
            statement = conn.createStatement();
            String sql = "select * from shoppingcar where  bookid="+id+" and username in (select username from  shoppingcar where username='" + username + "')";
            rs=statement.executeQuery(sql);
            {
                while(rs.next()){
                    s.setUsername(rs.getString(1));
                    s.setBookid(rs.getString(2));
                    s.setBookname(rs.getString(3));
                    s.setBookprice(rs.getInt(4));
                    s.setBooknumber(rs.getInt(5));
                }
            }
            rs.close();
            conn.close();
            return s;
        } catch (SQLException e){
            e.printStackTrace();
        }
        finally {
            JDBCUtil.close(statement, conn);
        }
        return s;
    }
    public int Queryone(String username, String id){
        //连接数据库
        Connection conn = null;
        Statement statement=null;
        ResultSet rs=null;
        int number=1;
        try {
            conn = JDBCUtil.getConnection();
            statement = conn.createStatement();
            String sql = "select * from shoppingcar where  username='" + username + "'" ;
            rs=statement.executeQuery(sql);
            {
                while(rs.next()){
                    if(rs.getString(2).equals(id))
                    number+=(rs.getInt(5));
                }
            }
            rs.close();
            conn.close();
        } catch (SQLException e){
            e.printStackTrace();
        }
        finally {
            JDBCUtil.close(statement, conn);
        }
        return number;
    }

    public int Queryone2(String username, String id){
        //连接数据库
        Connection conn = null;
        Statement statement=null;
        ResultSet rs=null;
        int number=0;
        try {
            conn = JDBCUtil.getConnection();
            statement = conn.createStatement();
            String sql = "select * from shoppingcar where  username='" + username + "'" ;
            rs=statement.executeQuery(sql);
            {
                while(rs.next()){
                    if(rs.getString(2).equals(id))
                        number=(rs.getInt(5));
                }
            }
            rs.close();
            conn.close();
        } catch (SQLException e){
            e.printStackTrace();
        }
        finally {
            JDBCUtil.close(statement, conn);
        }
        return number;
    }
    public List<ShoppingCar> Queryall(String username){
        //连接数据库
        Connection conn = null;
        Statement statement=null;
        ResultSet rs=null;
        List<ShoppingCar> list=new ArrayList<ShoppingCar>();
        try {
            conn = JDBCUtil.getConnection();
            statement = conn.createStatement();
            String sql = "select * from shoppingcar where username='" + username + "'";
            rs=statement.executeQuery(sql);
            while(rs.next()){
                ShoppingCar s=new ShoppingCar();
                s.setUsername(rs.getString(1));
                s.setBookid(rs.getString(2));
                s.setBookname(rs.getString(3));
                s.setBookprice(rs.getInt(4));
                s.setBooknumber(rs.getInt(5));
                list.add(s);
            }
            rs.close();
            conn.close();
            return list;
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JDBCUtil.close(statement, conn);
        }
        return list;
    }

    public List<ShoppingCar> Queryallorderlist(){
        //连接数据库
        Connection conn = null;
        Statement statement=null;
        ResultSet rs=null;
        List<ShoppingCar> list=new ArrayList<ShoppingCar>();
        try {
            conn = JDBCUtil.getConnection();
            statement = conn.createStatement();
            String sql = "select * from orderlist";
            rs=statement.executeQuery(sql);
            while(rs.next()){
                ShoppingCar s=new ShoppingCar();
                s.setUsername(rs.getString(1));

                System.out.println(s.getUsername());//调试

                s.setBookid(rs.getString(2));
                s.setBookname(rs.getString(3));
                s.setBookprice(rs.getDouble(4));
                s.setBooknumber(rs.getInt(5));
                list.add(s);
            }
            rs.close();
            conn.close();
            return list;
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JDBCUtil.close(statement, conn);
        }
        return list;
    }
    public void updatenumber(String id,int number){
        //连接数据库
        Connection conn = null;
        PreparedStatement psql=null;
        ResultSet rs=null;
        try {
            conn = JDBCUtil.getConnection();
            psql= conn.prepareStatement("update book set bNumber = ? where bID=?");
            psql.setInt(1,number);
            psql.setString(2,id);
            psql.execute();
            conn.close();
        } catch (SQLException e){
            e.printStackTrace();
        }
        finally {
            JDBCUtil.close(psql, conn);
        }
    }
    public void drop(String username){
        //连接数据库
        Connection conn = null;
        PreparedStatement psql=null;
        ResultSet rs=null;
        try {
            conn = JDBCUtil.getConnection();
            psql= conn.prepareStatement("delete from shoppingcar where username=?");
            psql.setString(1,username);
            psql.execute();
            conn.close();
        } catch (SQLException e){
            e.printStackTrace();
        }        finally {
            JDBCUtil.close(psql, conn);
        }
    }
    //单个结算后把记录写入订单表
    public void orderlist1(ShoppingCar s){
        //连接数据库
        Connection conn = null;
        PreparedStatement psql=null;
        ResultSet rs=null;
        try {
            conn = JDBCUtil.getConnection();
            psql= conn.prepareStatement("insert orderlist(customer, bookId, bookName, bookPrice, bookNumber)"+"values(?,?,?,?,?)");
                psql.setString(1,s.getUsername());
                psql.setString(2, s.getBookid());
                psql.setString(3, s.getBookname());
                psql.setDouble(4,s.getBookprice());
                psql.setInt(5,s.getBooknumber());
                psql.execute();
            conn.close();
        } catch (SQLException e){
            e.printStackTrace();
        }finally {
            JDBCUtil.close(psql, conn);
        }
    }
    //结算后把购物车记录写入订单表
    public void orderlist(List<ShoppingCar> list){
        //连接数据库
        Connection conn = null;
        PreparedStatement psql=null;
        ResultSet rs=null;
        try {
            conn = JDBCUtil.getConnection();
            psql= conn.prepareStatement("insert orderlist(customer, bookId, bookName, bookPrice, bookNumber)"+"values(?,?,?,?,?)");
            for(ShoppingCar s:list){
                psql.setString(1,s.getUsername());
                psql.setString(2, s.getBookid());
                psql.setString(3, s.getBookname());
                psql.setDouble(4,s.getBookprice());
                psql.setInt(5,s.getBooknumber());
                psql.execute();
            }
            conn.close();
        } catch (SQLException e){
            e.printStackTrace();
        }finally {
            JDBCUtil.close(psql, conn);
        }
    }
   public List<ShoppingCar> showuserorderlist(String username){
       //连接数据库
       Connection conn = null;
       Statement statement=null;
       ResultSet rs=null;
       List<ShoppingCar> list=new ArrayList<ShoppingCar>();
       try {
           conn = JDBCUtil.getConnection();
           statement = conn.createStatement();
           String sql = "select * from orderlist where customer='" + username + "'";
           rs=statement.executeQuery(sql);
           while(rs.next()){
               ShoppingCar s=new ShoppingCar();
               s.setBookid(rs.getString(2));
               s.setBookname(rs.getString(3));
               s.setBookprice(rs.getInt(4));
               s.setBooknumber(rs.getInt(5));
               list.add(s);
           }
           rs.close();
           conn.close();
           return list;
       } catch (SQLException e) {
           e.printStackTrace();
       }finally {
           JDBCUtil.close(statement, conn);
       }
       return list;
   }

    public void deleteonebook(String username,String id){
        //连接数据库
        Connection conn = null;
        PreparedStatement psql=null;
        ResultSet rs=null;
        try {
            conn = JDBCUtil.getConnection();
            psql= conn.prepareStatement("delete from shoppingcar where username=? and bookid in (select bookid from shoppingcar where bookid=?)");
            psql.setString(1,username);
            psql.setString(2,id);
            psql.execute();
            conn.close();
        } catch (SQLException e){
            e.printStackTrace();
        }        finally {
            JDBCUtil.close(psql, conn);
        }
    }
}
