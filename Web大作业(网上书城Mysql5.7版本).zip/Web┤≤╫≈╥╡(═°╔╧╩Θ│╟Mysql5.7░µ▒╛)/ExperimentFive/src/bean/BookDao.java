package bean;

import utils.JDBCUtil;

import java.sql.*;
import java.util.ArrayList;

import java.util.List;

public class BookDao{

    public Book Querybook(String id){
        //连接数据库
        Connection conn = null;
        Statement statement=null;
        ResultSet rs=null;
        Book b=new Book();
        try {
            conn = JDBCUtil.getConnection();
            statement = conn.createStatement();
            String sql = "SELECT * FROM atm.book WHERE bID="+id;
            rs=statement.executeQuery(sql);
            while(rs.next()){
                b.setName(rs.getString(1));

                b.setAuthor(rs.getString(2));

                b.setType(rs.getString(3));

                b.setId(rs.getString(4));

                b.setNumber(rs.getInt(5));

                b.setPrice(rs.getInt(6));

                System.out.println(b.getNumber());
                return b;
            }
            rs.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JDBCUtil.close(statement, conn);
        }
        return b;
    }
    public List<Book> allBooks(){
        //连接数据库
        Connection conn = null;
        Statement statement=null;
        ResultSet rs=null;
        List<Book> list=new ArrayList<Book>();
        try {
            conn = JDBCUtil.getConnection();
            statement = conn.createStatement();
            String sql = "select * from book";
            rs=statement.executeQuery(sql);
            while(rs.next()){

                Book b=new Book();

                b.setName(rs.getString(1));

                b.setAuthor(rs.getString(2));

                b.setType(rs.getString(3));

                b.setId(rs.getString(4));

                b.setNumber(rs.getInt(5));

                b.setPrice(rs.getInt(6));

                list.add(b);
            }
            rs.close();
            conn.close();
            return list;
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JDBCUtil.close(statement, conn);
        }
        return list;
    }

    public void updateprice(String name,int price){
        Connection conn = null;
        PreparedStatement psql=null;
        ResultSet rs=null;
        try {
            conn = JDBCUtil.getConnection();
            psql=conn.prepareStatement("update book set bPrice=? where bName='" + name + "'");
            psql.setInt(1,price);
            psql.execute();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JDBCUtil.close(psql, conn);
        }
    }

     public void updatenumber(String name,int number){
        Connection conn = null;
        PreparedStatement psql=null;
        ResultSet rs=null;
        try {
            conn = JDBCUtil.getConnection();
            psql=conn.prepareStatement("update book set bNumber=? where bName='" + name + "'");
            psql.setInt(1,number);
            psql.execute();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JDBCUtil.close(psql, conn);
        }
    }

    public void updatenumber2(String id,int number){
        Connection conn = null;
        PreparedStatement psql=null;
        ResultSet rs=null;
        try {
            conn = JDBCUtil.getConnection();
            psql=conn.prepareStatement("update book set bNumber=? where bID="+id);
            psql.setInt(1,number);
            psql.execute();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JDBCUtil.close(psql, conn);
        }
    }

    public void deletebook(String id){
        //连接数据库
        Connection conn = null;
        Statement statement=null;
        ResultSet rs=null;
        try {
            conn = JDBCUtil.getConnection();
            statement = conn.createStatement();
            String sql = "delete  from book where bID="+id;
            statement.executeUpdate(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JDBCUtil.close(statement, conn);
        }
    }

}

