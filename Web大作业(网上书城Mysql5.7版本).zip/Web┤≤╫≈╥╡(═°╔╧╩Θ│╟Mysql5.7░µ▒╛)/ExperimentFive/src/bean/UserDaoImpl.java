package bean;

import utils.JDBCUtil;

import java.sql.*;

public class UserDaoImpl implements UserDao {

    @Override
    public void adduser(User u) {
        //连接数据库
        Connection conn = null;
        PreparedStatement psql=null;
        ResultSet rs=null;
        try {
            conn = JDBCUtil.getConnection();
            String sql = "insert into user value (?,?,?)";
            conn = JDBCUtil.getConnection();
            psql=conn.prepareStatement(sql);
            psql.setString(1,u.getName());
            psql.setString(2,u.getPassword());
            psql.setString(3,u.getAddr());
            int i = psql.executeUpdate();
            if(i>0){
                System.out.println("插入成功！");
            }else {
                System.out.println("插入失败！");
            }
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JDBCUtil.close(psql, conn);
        }
    }

    @Override
    public User queryuser(String username) {

        //连接数据库
        Connection conn = null;
        Statement statement=null;
        ResultSet rs=null;
        User u=new User();

        try {
            conn = JDBCUtil.getConnection();
            statement = conn.createStatement();
            String sql = "select * from user where name ='" + username + "'";
            rs=statement.executeQuery(sql);
            while(rs.next()){

                u.setName(rs.getString("name"));
                u.setPassword(rs.getString("password"));
            }
            rs.close();
            conn.close();
            return u;
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JDBCUtil.close(statement, conn);
        }
        return u;
    }
    public void updatepassword(String name,String password){
        Connection conn = null;
        PreparedStatement psql=null;
        ResultSet rs=null;
        try {
            conn = JDBCUtil.getConnection();
            psql=conn.prepareStatement("update user set password=? where name='" + name + "'");
            psql.setString(1,password);
            psql.execute();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JDBCUtil.close(psql, conn);
        }
    }

    public void updateaddr(String name,String addr){
        Connection conn = null;
        PreparedStatement psql=null;
        ResultSet rs=null;
        try {
            conn = JDBCUtil.getConnection();
            psql=conn.prepareStatement("update user set atm.user.address=? where name='" + name + "'");
            psql.setString(1,addr);
            psql.execute();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JDBCUtil.close(psql, conn);
        }
    }
}
