package bean;

import java.util.List;

public interface ShoppingcarDao {
    public Book querybook(String id);

    public List<ShoppingCar> Queryall(String username);

    public List<ShoppingCar> Queryallorderlist();

    public int Queryone(String username,String id);
    public int Queryone2(String username, String id);

    public ShoppingCar Queryone1(String username,String id);
    public void DeleteBook(String id);
    public void inserts(Book b,String username,int number);
    public void update(Book b,String username,int number);
    public void updatenumber(String id,int number);
    public void drop(String username);
    public void orderlist1(ShoppingCar s);//向订单表添加单个订单记录
    public void orderlist(List<ShoppingCar> list);//向订单表添加订单记录
    public List<ShoppingCar> showuserorderlist(String username);//显示某个用户的所有订单

    public void deleteonebook(String username,String id);
}
