import bean.User;
import utils.JDBCUtil;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class test {
    public static void main(String[] args) {
        //连接数据库
        Connection conn = null;
        Statement statement=null;
        ResultSet rs=null;
        User u=new User();
        String username="Tom";
        try {
            conn = JDBCUtil.getConnection();
            statement = conn.createStatement();
            String sql = "select * from user where name='" + username + "'";
            rs=statement.executeQuery(sql);
            while(rs.next()){

                u.setName(rs.getString("name"));
                u.setPassword(rs.getString("password"));

            }
            rs.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JDBCUtil.close(statement, conn);
        }
        System.out.println(u.getName()+"++++++++++++++"+u.getPassword());
    }
}
