import utils.JDBCUtil;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
@WebServlet(name = "RegistServlet",urlPatterns = "/RegistServlet")
public class RegistServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("html/text;charset=utf-8");
        //1.获取数据
        String name = request.getParameter("name");
        String password = request.getParameter("password");
        String addr = request.getParameter("addr");

        //2.判断用户名不能为空
        if (name==null||"".equals(name)){
            System.out.println("用户名不能为空!");
            String s = "用户名不能为空";
            response.getWriter().write(s);
        }
        //连接数据库，插入数据
        Connection conn = null;
        PreparedStatement psta = null;
        String sql = "insert into user value (?,?,?)";

        try {
            conn = JDBCUtil.getConnection();
            psta = conn.prepareStatement(sql);
            psta.setString(1,name);
            psta.setString(2,password);
            psta.setString(3,addr);
            int i = psta.executeUpdate();
            if(i>0){
                response.sendRedirect("userlogin.html");
            }else {
                System.out.println("插入失败！");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JDBCUtil.close(psta,conn);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request,response);
    }
}
