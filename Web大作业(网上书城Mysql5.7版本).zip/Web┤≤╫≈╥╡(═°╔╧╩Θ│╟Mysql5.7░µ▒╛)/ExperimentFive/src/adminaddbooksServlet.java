import utils.JDBCUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet(name = "adminaddbooksServlet",urlPatterns = "/adminaddbooksServlet")
public class adminaddbooksServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("html/text;charset=utf-8");
        //1.获取数据
        String name = request.getParameter("name");
        String writer = request.getParameter("writer");
        String type=request.getParameter("type");
        String id=request.getParameter("id");
        int number= Integer.parseInt(request.getParameter("number"));
        int price= Integer.parseInt(request.getParameter("price"));
        //2.判断用户名不能为空
        /*if (name==null||"".equals(name)&&writer==null||"".equals(writer)&&type==null||"".equals(type)&&id==null||"".equals(id)&&number==0||"".equals(price)&&writer==null||"".equals(price)){
            String s = "书籍信息要写完整";
            response.getWriter().write(s);
            response.sendRedirect("addbooks.html");
        }*/
        //连接数据库，插入数据
        Connection conn = null;
        PreparedStatement psta = null;
        String sql = "insert into book value (?,?,?,?,?,?)";

        try {
            conn = JDBCUtil.getConnection();
            psta = conn.prepareStatement(sql);
            psta.setString(1,name);
            psta.setString(2,writer);
            psta.setString(3,type);
            psta.setString(4,id);
            psta.setInt(5,number);
            psta.setInt(6,price);
            psta.execute();
            /*int i = psta.executeUpdate(sql);
            if(i>0){
                //request.getRequestDispatcher("adminlogin.html").forward(request,response);
                response.sendRedirect("adminnavcation.jsp");
            }else {
                System.out.println("插入失败！");
            }*/
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JDBCUtil.close(psta,conn);
        }
        response.sendRedirect("adminnavcation.jsp");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    this.doPost(request,response);
    }
}
