/*
Navicat MySQL Data Transfer

Source Server         : DESKTOP-7UO4BFR
Source Server Version : 50725
Source Host           : localhost:3306
Source Database       : atm

Target Server Type    : MYSQL
Target Server Version : 50725
File Encoding         : 65001

Date: 2020-12-09 13:34:02
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `account`
-- ----------------------------
DROP TABLE IF EXISTS `account`;
CREATE TABLE `account` (
  `UserID` varchar(20) NOT NULL,
  `UserName` varchar(15) DEFAULT NULL,
  `money` int(11) DEFAULT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of account
-- ----------------------------
INSERT INTO `account` VALUES ('1815925066', '周文豪', '1400');
INSERT INTO `account` VALUES ('1815925067', '闫守建', '1400');

-- ----------------------------
-- Table structure for `admin`
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `name` varchar(20) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('俞敏洪', '123456');
INSERT INTO `admin` VALUES ('李嘉诚', '123456');
INSERT INTO `admin` VALUES ('王健林', '123456');
INSERT INTO `admin` VALUES ('马云', '123456');

-- ----------------------------
-- Table structure for `book`
-- ----------------------------
DROP TABLE IF EXISTS `book`;
CREATE TABLE `book` (
  `bName` varchar(20) NOT NULL,
  `bWtiter` varchar(15) DEFAULT NULL,
  `bType` varchar(15) DEFAULT NULL,
  `bID` varchar(15) DEFAULT NULL,
  `bNumber` int(11) DEFAULT NULL,
  `bPrice` int(11) DEFAULT NULL,
  PRIMARY KEY (`bName`),
  KEY `bID` (`bID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of book
-- ----------------------------
INSERT INTO `book` VALUES ('三体', '刘慈欣', '科幻小说', '004', '29', '55');
INSERT INTO `book` VALUES ('三国演义', '罗贯中', '四大名著', '001', '21', '35');
INSERT INTO `book` VALUES ('假面山庄', '东野圭吾', '外国小说', '005', '25', '88');
INSERT INTO `book` VALUES ('昆虫记', '法布尔', '文学', '033', '40', '40');
INSERT INTO `book` VALUES ('比索寓言', '比索', '寓言故事', '008', '2', '20');
INSERT INTO `book` VALUES ('活着', '余华', '现实主义小说', '006', '6', '36');
INSERT INTO `book` VALUES ('西游记', '吴承恩', '四大名著', '002', '23', '30');
INSERT INTO `book` VALUES ('钢铁是怎样炼成的', '尼古拉·奥斯特洛夫斯基', '外国名著', '003', '34', '56');

-- ----------------------------
-- Table structure for `orderlist`
-- ----------------------------
DROP TABLE IF EXISTS `orderlist`;
CREATE TABLE `orderlist` (
  `customer` varchar(20) DEFAULT NULL,
  `bookID` varchar(20) DEFAULT NULL,
  `bookName` varchar(20) DEFAULT NULL,
  `bookPrice` double(20,0) DEFAULT NULL,
  `bookNumber` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of orderlist
-- ----------------------------
INSERT INTO `orderlist` VALUES ('Tom', '003', '钢铁是怎样炼成的', '56', '1');
INSERT INTO `orderlist` VALUES ('Tom', '004', '三体', '55', '1');
INSERT INTO `orderlist` VALUES ('Tom', '005', '假面山庄', '88', '1');
INSERT INTO `orderlist` VALUES ('周文豪', '005', '假面山庄', '88', '1');
INSERT INTO `orderlist` VALUES ('周文豪', '005', '假面山庄', '88', '3');
INSERT INTO `orderlist` VALUES ('周文豪', '006', '活着', '36', '1');
INSERT INTO `orderlist` VALUES ('周文豪', '003', '钢铁是怎样炼成的', '56', '2');
INSERT INTO `orderlist` VALUES ('周文豪', '001', '三国演义', '35', '1');
INSERT INTO `orderlist` VALUES ('周文豪', '004', '三体', '55', '1');
INSERT INTO `orderlist` VALUES ('周文豪', '004', '三体', '55', '1');
INSERT INTO `orderlist` VALUES ('张世强', '004', '三体', '55', '1');
INSERT INTO `orderlist` VALUES ('周文豪', '004', '三体', '55', '1');
INSERT INTO `orderlist` VALUES ('张世强', '001', '三国演义', '35', '1');
INSERT INTO `orderlist` VALUES ('周文豪', '004', '三体', '55', '1');
INSERT INTO `orderlist` VALUES ('周文豪', '001', '三国演义', '35', '1');
INSERT INTO `orderlist` VALUES ('周文豪', '006', '活着', '36', '1');
INSERT INTO `orderlist` VALUES ('周文豪', '004', '三体', '55', '1');
INSERT INTO `orderlist` VALUES ('周文豪', '006', '活着', '36', '1');
INSERT INTO `orderlist` VALUES ('周文豪', '002', '西游记', '30', '2');
INSERT INTO `orderlist` VALUES ('闫守建', '007', '安徒生童话', '15', '1');
INSERT INTO `orderlist` VALUES ('闫守建', '004', '三体', '55', '1');
INSERT INTO `orderlist` VALUES ('闫守建', '003', '钢铁是怎样炼成的', '56', '1');

-- ----------------------------
-- Table structure for `shoppingcar`
-- ----------------------------
DROP TABLE IF EXISTS `shoppingcar`;
CREATE TABLE `shoppingcar` (
  `username` varchar(20) DEFAULT NULL,
  `bookid` varchar(20) DEFAULT NULL,
  `bookname` varchar(20) DEFAULT NULL,
  `bookprice` int(20) DEFAULT NULL,
  `booknumber` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of shoppingcar
-- ----------------------------

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `name` varchar(15) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  `address` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('CATs', '123456', '奥术大师大奥所');
INSERT INTO `user` VALUES ('James', '123456', '奥术大师大奥所');
INSERT INTO `user` VALUES ('Tom', '123456', '南洋理工学院12号公寓205');
INSERT INTO `user` VALUES ('zhou', '123456', '南阳理工学院12#201');
INSERT INTO `user` VALUES ('侯明明', '123456', '南阳理工学院12#201');
INSERT INTO `user` VALUES ('周五', '123456', '是的撒多所多所多所多所多、');
INSERT INTO `user` VALUES ('周文豪', '123456', '南阳理工学院');
INSERT INTO `user` VALUES ('张世强', '123456', '南洋理工学院12号公寓201');
INSERT INTO `user` VALUES ('曹瑾', '123456', '南阳理工学院12#215');
INSERT INTO `user` VALUES ('朱命豪', '666666', '南阳理工学院');
INSERT INTO `user` VALUES ('王康', '123456', '河南大学');
INSERT INTO `user` VALUES ('米军臣', '123456', '南阳理工学院12#212');
INSERT INTO `user` VALUES ('胡广涛', '123456', '南阳理工学院12#218');
INSERT INTO `user` VALUES ('薛之谦', '123456', '南阳理工学院12#215');
INSERT INTO `user` VALUES ('邝凯兴', '123456', '南阳理工学院12#331');
INSERT INTO `user` VALUES ('闫守建', '123456', '南洋理工学院12号公寓201');
INSERT INTO `user` VALUES ('靳凌霄', '123456', '南阳理工学院12#201');

-- ----------------------------
-- Table structure for `user2`
-- ----------------------------
DROP TABLE IF EXISTS `user2`;
CREATE TABLE `user2` (
  `id` varchar(11) NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `address` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of user2
-- ----------------------------
INSERT INTO `user2` VALUES ('1815925061', 'sdsdssdsd', '123456', '南阳理工');
INSERT INTO `user2` VALUES ('1815925066', '周文豪', '123456', '南阳理工');
INSERT INTO `user2` VALUES ('1815925110', '闫守建', '123456', '南阳理工');
INSERT INTO `user2` VALUES ('1815925116', '周六', '123456', '南阳理工');
INSERT INTO `user2` VALUES ('1815925118', '周五', '123456', '南阳理工');
INSERT INTO `user2` VALUES ('1815925167', '侯明明', '123456', '南阳理工');

-- ----------------------------
-- Table structure for `users`
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `UserID` varchar(20) NOT NULL,
  `Username` varchar(15) DEFAULT NULL,
  `UserPassword` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('1815925066', '周文豪', '123456');
INSERT INTO `users` VALUES ('1815925067', '闫守建', '123456');
